## Sky Void Worldgen with Structures
The `skyvoid_worldgen_structures` data pack generates an infinite void world with properties akin to the original SkyBlock. No blocks will generate except for structures. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
