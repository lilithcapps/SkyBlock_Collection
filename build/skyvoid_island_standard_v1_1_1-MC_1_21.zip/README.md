## Standard SkyBlock
For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
### Starter Island
This island will generate with 54 dirt, 26 grass blocks, 1 bedrock (at world spawn), an oak tree, and a chest with an ice block and bucket of lava. 

### Nether Island
The nether island will generate with 40 netherrack, 7 crimson nylium, 7 warped nylium, 2 soul sand, 2 nether wart, and 14 obsidian for the portal.

### Dependencies
[Sky Void Worldgen](https://github.com/BPR02/SkyBlock_Collection/blob/main/src/worldgen) must be installed alongside this data pack. 
