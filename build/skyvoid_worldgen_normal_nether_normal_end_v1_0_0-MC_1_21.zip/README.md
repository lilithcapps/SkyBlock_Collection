## Sky Void Worldgen (Normal End)
The `skyvoid_worldgen_normal_end` data pack generates an infinite void world with properties akin to the original SkyBlock, except with a normal end dimension. Every entrance end portal will have a single block of lava beneath it. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
