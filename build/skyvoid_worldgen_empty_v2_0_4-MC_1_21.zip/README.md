## Sky Void Worldgen (Empty)
The `skyvoid_worldgen` data pack generates an infinite void world with properties akin to the original SkyBlock. No blocks or entities will generate. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
